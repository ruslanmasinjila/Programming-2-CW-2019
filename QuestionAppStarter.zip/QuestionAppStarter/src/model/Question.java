/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author mga
 */
abstract
public class Question {

    /**
     *
     */
    protected final int id;

    /**
     *
     */
    protected String questionText;

    /**
     *
     */
    protected String topicArea;
    
    /**
     *
     */
    protected static int lastIdAllocated = 0;
    
    static final char EOLN='\n';       
    static final String QUOTE="\""; 

    /**
     *
     */
    public Question() {
        this.id = ++lastIdAllocated;
        this.questionText = "TBC";
        this.topicArea = "TBC";        
    }

    /**
     *
     * @param questionText
     * @param topicArea
     */
    public Question(String questionText, String topicArea) {
        this.id = ++lastIdAllocated;
        this.questionText = questionText;
        this.topicArea = topicArea;
    }

    /**
     *
     * @param id
     * @param questionText
     * @param topicArea
     */
    public Question(int id, String questionText, String topicArea) {
        this.id = id;
        this.questionText = questionText;
        this.topicArea = topicArea;
        if (id > Question.lastIdAllocated)
            Question.lastIdAllocated = id;            
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }    

    // Methods required: getters, setters, add, hashCode, equals, compareTo, comparator

    /**
     *
     * @return
     */
    
    @Override
    public String toString() {
        return "\nQuestion Id: " + id + " - Question Text: " + questionText +            
                " - Topic Area: " + topicArea + "\n";
    }      
}
