package repositories;

import model.Question;

public interface RepositoryInterface {

    /**
     *
     * @param item
     */
    void add(Question item);

    /**
     *
     * @param id
     * @return
     */
    Question getItem(int id);

    //CollectionChoice<Question> getItems();

    /**
     *
     * @param id
     */
    
    void remove(int id);

    //void setItems(CollectionChoice<Question> items);

    /**
     *
     * @param filename
     */
    
    void store(String filename);

    /**
     *
     * @return
     */
    @Override
    String toString();
    
}
